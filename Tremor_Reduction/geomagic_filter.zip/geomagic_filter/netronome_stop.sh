#!/usr/bin/env bash
sudo /opt/netronome/bin/nfp-nffw unload
echo -e "nffw unloaded"
sudo /opt/netronome/p4/bin/rtecli design-unload
echo -e "rtecli unloaded"
sudo systemctl stop nfp-sdk6-rte.service
echo -e "nfp sdk service stopped"
