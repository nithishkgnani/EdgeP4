#!/usr/bin/env bash
sudo /opt/netronome/p4/bin/rtecli design-unload
sudo /opt/netronome/bin/nfp-nffw unload
sudo /opt/netronome/p4/bin/rtecli design-load -f basic.nffw -p out/pif_design.json
sudo /opt/netronome/p4/bin/rtecli config-reload -c user_config_phy.json
