#!/usr/bin/env python3
import sys
import struct
import os

from scapy.all import sniff, sendp, hexdump, get_if_list, get_if_hwaddr
from scapy.all import Packet, IPOption
from scapy.all import ShortField, IntField, LongField, BitField, FieldListField, FieldLenField
from scapy.all import IP, TCP, UDP, Raw
from scapy.layers.inet import _IPOption_HDR
from metadataheader import coordinate_metadata, telemetry

def get_if():
    ifs=get_if_list()
    iface=None
    for i in get_if_list():
        if "vf0_1" in i:
            iface=i
            break;
    if not iface:
        print("Cannot find vf0_1 interface")
        exit(1)
    return iface

class IPOption_MRI(IPOption):
    name = "MRI"
    option = 31
    fields_desc = [ _IPOption_HDR,
                    FieldLenField("length", None, fmt="B",
                                  length_of="swids",
                                  adjust=lambda pkt,l:l+4),
                    ShortField("count", 0),
                    FieldListField("swids",
                                   [],
                                   IntField("", 0),
                                   length_from=lambda pkt:pkt.count*4) ]
def handle_pkt(pkt):
    if UDP in pkt and pkt[UDP].dport == 38005:
        print("got a packet")
        pkt.show2()
        #print(pkt.load)
    #    hexdump(pkt)
        sys.stdout.flush()


def main():
    #ifaces = [i for i in os.listdir('/sys/class/net/') if 'vf0_' in i]  #
    #print(sys.argv)
    #iface = ifaces[0]
    if len(sys.argv)<2:
        print('pass 1 argument:<destination>')
        exit(1)
    iface = sys.argv[1]
    print(("sniffing on %s" % iface))
    sys.stdout.flush()
    sniff(iface = iface,
          prn = lambda x: handle_pkt(x))

if __name__ == '__main__':
    main()
