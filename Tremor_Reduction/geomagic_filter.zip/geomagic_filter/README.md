# Tremor reduction Notes
Algorithm:  
<img src="trem_red_algo.png" alt="Tremor reduction algorithm" width="50%">

Storing the values: 
* old_x, old_y, old_z (step 7)
* differences between current and old x, y, z (Step 1)
* Calculate and store absolute values of differences using 2's complement (steps 2-4)

## Results
|z  |old_z|diff_z|abs(diff_z)|
|---|-----|------|-----------|
|50 |20   |1e    |1e         |
|20 |50   |ffe2  |1e         |
|50 |20   |1e    |1e         |
|80 |50   |1e    |1e         |
|50 |80   |ffe2  |ffe2       |
