ip netns exec box1 ethtool -K vf0_0 rx off
ip netns exec box1 ethtool -K vf0_0 tx off
ip netns exec box2 ethtool -K vf0_1 rx off
ip netns exec box2 ethtool -K vf0_1 tx off
ip netns exec box1 sysctl net.ipv4.ip_forward=1
ip netns exec box2 sysctl net.ipv4.ip_forward=1