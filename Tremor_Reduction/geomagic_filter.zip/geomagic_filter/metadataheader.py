from scapy.all import *
import sys, os
from ctypes import *

#TYPE_MetaData = 0xA0
#TYPE_IPV4 = 0x0800

class coordinate_metadata(Packet):
    _pack_ = 1
    name = "coordinate_metadata"
    fields_desc = [
        #BitField("P2", 0, 16)
        BitField("sid", 0, 16),
        BitField("robot_id", 0, 16),
        SignedShortField("x", 0),
        SignedShortField("y", 0),
        SignedShortField("z", 0),
        SignedShortField("qx", 0),
        SignedShortField("qy", 0),
        SignedShortField("qz", 0),
        SignedShortField("qw", 0),
        BitField("b1", 0, 16),
        BitField("b2", 0, 16),
        BitField("f0", 0, 16),
        BitField("f1", 0, 16),
        BitField("f2", 0, 16),
        BitField("f3", 0, 16),
        BitField("f4", 0, 16),
        BitField("f5", 0, 16),
        BitField("f6", 0, 16),
        BitField("f7", 0, 16),
        BitField("f8", 0, 16),
        BitField("f9", 0, 16),
        BitField("f10", 0, 16),
        BitField("f11", 0, 16),
        BitField("f12", 0, 16),
        BitField("f13", 0, 16),
        BitField("f14", 0, 16),
        BitField("key0", 0, 16),
        BitField("key1", 0, 16)

    ]
    def mysummary(self):
        return self.sprintf(" sid=%sid%\n robot_id=%robot_id%\n x=%x%\n y=%y%\n z=%z%\n")



class telemetry(Packet):
    name = "coordinate_metadata"
    fields_desc = [
        #BitField("P2", 0, 16)
        BitField("ing_glb_tstamp", 0, 64),
        BitField("cur_glb_tstamp", 0, 64),
        BitField("pkt_len", 0, 16),
        BitField("ig_port", 0, 16),
        BitField("eg_port", 0, 16)
    ]
    def mysummary(self):
        return self.sprintf(" cur_glb_tstamp=%cur_glb_tstamp%\n")


bind_layers(UDP, coordinate_metadata)
bind_layers(coordinate_metadata, telemetry)
