/* -*- P4_16 -*- */
#include <core.p4>
#include <v1model.p4>

const bit<16> TYPE_IPV4 = 0x800;
const bit<16> TYPE_ARP = 0x806;

//const bit<8> IPPROTO_UDP = 17;
const bit<8> IPPROTO_UDP = 0x11;

/*************************************************************************
*********************** H E A D E R S  ***********************************
*************************************************************************/

typedef bit<16>  egressSpec_t;
typedef bit<48> macAddr_t;
typedef bit<32> ip4Addr_t;

typedef bit<16> bit16_t;
typedef bit<48> bit48_t;
typedef bit<32> bit32_t;
typedef int<32> int32_t;
typedef int<16> int16_t;

header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

header ipv4_t {
    bit<4>    version;
    bit<4>    ihl;
    bit<8>    diffserv;
    bit<16>   totalLen;
    bit<16>   identification;
    bit<3>    flags;
    bit<13>   fragOffset;
    bit<8>    ttl;
    bit<8>    protocol;
    bit<16>   hdrChecksum;
    ip4Addr_t srcAddr;
    ip4Addr_t dstAddr;
}

header udp_t {
    bit16_t srcPort;
    bit16_t dstPort;
    bit16_t length;
    bit16_t checksum;
}

/*custom defined header for coordinates - 98 bytes */
header coordinate_metadata_t {
    bit16_t sid;
    bit16_t robot_id;
    int16_t x;
    int16_t y;
    int16_t z;
    int16_t qx;
    int16_t qy;
    int16_t qz;
    int16_t qw;
    bit<16> b1;
    bit<16> b2;
    bit16_t f0;
    bit16_t f1;
    bit16_t f2;
    bit16_t f3;
    bit16_t f4;
    bit16_t f5;
    bit16_t f6;
    bit16_t f7;
    bit16_t f8;
    bit16_t f9;
    bit16_t f10;
    bit16_t f11;
    bit16_t f12;
    bit16_t f13;
    bit16_t f14;
    bit16_t key0;
    bit16_t key1;
}

/* custom defined header for telemetry - 22 bytes */
header telemetry_t {
    bit<64> ing_glb_tstamp;
    bit<64> cur_glb_tstamp;
    bit16_t pkt_len;
    bit16_t ig_port;
    bit16_t eg_port;
}


header intrinsic_metadata_t {
    bit<64> ingress_global_timestamp;
    bit<64> current_global_timestamp;
}

struct metadata {
    intrinsic_metadata_t intrinsic_metadata;
}

struct headers {
    ethernet_t ethernet;
    ipv4_t ipv4;
    udp_t udp;
    coordinate_metadata_t coordinate_metadata;
    telemetry_t telemetry;
}


/* Define constant(s) for register operations */
const bit<32> REG_IDX      = 0x0;

register<int<16>>(1) old_x;
register<int<16>>(1) old_y;
register<int<16>>(1) old_z;


register<int<16>>(3) diff_raw;
register<int<16>>(3) diff_abs;

/*************************************************************************
*********************** P A R S E R  ***********************************
*************************************************************************/

parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t standard_metadata) {

    state start {
        transition parse_ethernet;
    }

    state parse_ethernet {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            TYPE_IPV4: parse_ipv4;
            default: accept;
        }
    }
    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition select(hdr.ipv4.protocol) {
            IPPROTO_UDP: parse_udp;
            default: accept;
        }
    }

    state parse_udp {
        packet.extract(hdr.udp);
        transition parse_coordinate_metadata;
    }

    state parse_coordinate_metadata {
        packet.extract(hdr.coordinate_metadata);
        transition parse_telemetry;
    }   

    state parse_telemetry {
        packet.extract(hdr.telemetry);
        transition accept;
    }

}

/*************************************************************************
************   C H E C K S U M    V E R I F I C A T I O N   *************
*************************************************************************/

control MyVerifyChecksum(inout headers hdr, inout metadata meta) {
    apply {  }
}


/*************************************************************************
**************  I N G R E S S   P R O C E S S I N G   *******************
*************************************************************************/

control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t standard_metadata) {
    
    int <16> temp_x;
    int <16> temp_y;
    int <16> temp_z;
    int <16> diff_x;
    int <16> diff_y;
    int <16> diff_z;

    action drop() {
        mark_to_drop();
    }

    action mac_forward(egressSpec_t port){
        //hdr.coordinate_metadata.x = hdr.coordinate_metadata.x - 1;
        standard_metadata.egress_spec = port;
    }

    table mac_exact {
        key = {
            standard_metadata.ingress_port: exact;
        }
        actions = {
            mac_forward;
            drop;
            NoAction;
        }
        size = 1024;
        default_action = NoAction;
    }
    
    apply {
        if (hdr.coordinate_metadata.isValid()) {

            if (standard_metadata.ingress_port==0){ //incoming on p0
                    mac_exact.apply(); //just forward from P0 to P1 (P0 is connected to the outside network, P1 to the Geomagic Touch)
                }
                
            else if (standard_metadata.ingress_port==1) { //incoming on p1 
                old_x.read(temp_x, (bit<32>)REG_IDX);
                old_y.read(temp_y, (bit<32>)REG_IDX);
                old_z.read(temp_z, (bit<32>)REG_IDX);
                diff_x = hdr.coordinate_metadata.x - temp_x;
                diff_y = hdr.coordinate_metadata.y - temp_y;
                diff_z = hdr.coordinate_metadata.z - temp_z;

                diff_raw.write(0x00, diff_x);
                diff_raw.write(0x01, diff_y);
                diff_raw.write(0x02, diff_z);

                //signed comparison doesn't seem to work, hence this is required.
                if (diff_x>>15 != 0) //negative
                {
                    diff_x = ~diff_x + 1; //get magnitude of the 2s complement represented negative number
                }
                if (diff_y>>15 != 0) //negative
                {
                    diff_y = ~diff_y + 1; //get magnitude of the 2s complement represented negative number
                }
                if (diff_z>>15 != 0) //negative
                {
                    diff_z = ~diff_z + 1; //get magnitude of the 2s complement represented negative number
                }

                diff_abs.write(0x00, diff_x);
                diff_abs.write(0x01, diff_y);
                diff_abs.write(0x02, diff_z);

                // if ((diff_x < 10) && (diff_y < 10) && (diff_z < 10) )
                // {
                //     drop();
                //     //drop packet, don't update
                // }
                // else
                // {
                //     old_x.write((bit<32>)REG_IDX, hdr.coordinate_metadata.x);
                //     old_y.write((bit<32>)REG_IDX, hdr.coordinate_metadata.y);
                //     old_z.write((bit<32>)REG_IDX, hdr.coordinate_metadata.z); //update values
                //     mac_exact.apply(); //forward packet
                // }

                if ((diff_x > 10) || (diff_y > 10) || (diff_z > 10) )
                {
                    old_x.write((bit<32>)REG_IDX, hdr.coordinate_metadata.x);
                    old_y.write((bit<32>)REG_IDX, hdr.coordinate_metadata.y);
                    old_z.write((bit<32>)REG_IDX, hdr.coordinate_metadata.z); //update values
                    mac_exact.apply(); //forward packet
                }
                else
                {
                    drop();
                    //drop packet, don't update
                }

            }

        }
        else{
            mac_exact.apply();
        }
        
        if (hdr.ipv4.isValid()) {
            hdr.ipv4.ttl = hdr.ipv4.ttl- 1;     //reduce TTL for IP packets (not required for a L2 switch)
        }
    }
}

/*************************************************************************
****************  E G R E S S   P R O C E S S I N G   *******************
*************************************************************************/

control MyEgress(inout headers hdr,
                 inout metadata meta,
                 inout standard_metadata_t standard_metadata) {
    apply {  }
}

/*************************************************************************
*************   C H E C K S U M    C O M P U T A T I O N   **************
*************************************************************************/

control MyComputeChecksum(inout headers  hdr, inout metadata meta) {
     apply {
	update_checksum(
	    hdr.ipv4.isValid(),
            { hdr.ipv4.version,
	      hdr.ipv4.ihl,
              hdr.ipv4.diffserv,
              hdr.ipv4.totalLen,
              hdr.ipv4.identification,
              hdr.ipv4.flags,
              hdr.ipv4.fragOffset,
              hdr.ipv4.ttl,
              hdr.ipv4.protocol,
              hdr.ipv4.srcAddr,
              hdr.ipv4.dstAddr },
            hdr.ipv4.hdrChecksum,
            HashAlgorithm.csum16);
    }
}

/*************************************************************************
***********************  D E P A R S E R  *******************************
*************************************************************************/

control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.ipv4);
        packet.emit(hdr.udp);
        packet.emit(hdr.coordinate_metadata);
        packet.emit(hdr.telemetry);
    }
}

/*************************************************************************
***********************  S W I T C H  *******************************
*************************************************************************/

V1Switch(
MyParser(),
MyVerifyChecksum(),
MyIngress(),
MyEgress(),
MyComputeChecksum(),
MyDeparser()
) main;
