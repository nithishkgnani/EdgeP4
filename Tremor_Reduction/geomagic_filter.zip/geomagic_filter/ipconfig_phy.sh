#!/usr/bin/env bash
ip netns del box1
sleep 0.5
ip netns del box2
sleep 0.5
ip netns del box3
sleep 0.5

ip netns add box1
sleep 0.5
ip netns add box2
sleep 0.5

echo -e "Boxes added"

# Adding netronome vf interfaces to the box
echo -e "Adding netronome vf interfaces to the two boxes"

ip link set vf0_0 netns box1
echo -e "vf0_0 added in box1"

ip link set vf0_1 netns box2
echo -e "vf0_1 added in box2"


### Giving them IP addresses
ip -n box1 addr add 10.0.0.1/24 dev vf0_0
sleep 0.5
ip -n box2 addr add 10.0.0.2/24 dev vf0_1
sleep 0.5
ip -n box1 addr add 127.0.0.1/24 dev lo
sleep 0.5
ip -n box2 addr add 127.0.0.1/24 dev lo
sleep 0.5

echo -e "IP addresses have been set"

### Setting mac addresses
ip netns exec box1 ifconfig vf0_0 hw ether 00:15:4d:00:00:00
sleep 0.5
ip netns exec box2 ifconfig vf0_1 hw ether 00:15:4d:00:00:01
sleep 0.5


echo -e "MAC addresses have been set"

### getting the link up (from the default down)
ip -n box1 link set vf0_0 up
sleep 0.5
ip -n box2 link set vf0_1 up
sleep 0.5


echo -e "The links are up."
