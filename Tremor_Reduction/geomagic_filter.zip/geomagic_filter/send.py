#!/usr/bin/env python3
import argparse
import sys
import socket
import random
import struct
import numpy
from ctypes import *

from scapy.all import sendp, send, get_if_list, get_if_hwaddr
from scapy.all import Packet
from scapy.all import Ether, IP, UDP, TCP

from metadataheader import coordinate_metadata, telemetry

def get_if(interface):
    ifs=get_if_list()
    iface=None # "h1-eth0"
    for i in get_if_list():
        if interface in i:
            iface=i
            break;
    if not iface:
        print("Cannot find "+interface+ " interface")
        exit(1)
    return iface

def main():

    if len(sys.argv)<4:
        print('pass 3 arguments:<source> <destination> "<message>"')
        exit(1)
    addr_src = sys.argv[1]
    addr = sys.argv[2]
    iface = get_if(sys.argv[1])
    
    x_val = int(sys.argv[3])
    y_val = int(sys.argv[4])
    z_val = int(sys.argv[5])

    #bytes_val = x_val.to_bytes(2, 'little')
    #x_val = c_int32(5)
    #print(x_val)
    #print(sys.getsizeof(x_val))

    print(("sending on interface %s to %s" % (iface, str(addr))))
    pkt =  Ether(src=get_if_hwaddr(iface), dst='ff:ff:ff:ff:ff:ff')
    #pkt = pkt /IP(dst=addr) / UDP(dport=1234, sport=random.randint(49152,65535)) / sys.argv[3] / sys.argv[3]
    pkt = pkt /IP(dst=addr) / UDP(dport=38005, sport=random.randint(49152,65535)) / coordinate_metadata(x = x_val, y = y_val, z = z_val)  / telemetry()
    pkt.show2()
    sendp(pkt, iface=iface, verbose=False)


if __name__ == '__main__':
    main()
